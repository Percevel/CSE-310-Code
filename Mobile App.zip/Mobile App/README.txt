# Overview

{Provide a description of your app.  Describe how to use the app.}

A simple cookie clicker that saves the amount of clicks you've had.

{Provide a link to your YouTube demonstration.  It should be a 4-5 minute demo of the app running and a walkthrough of the code.}

[Software Demo Video]https://youtu.be/2uF5MTm1udw

# Development Environment

{Describe the tools that you used to develop the app}

Android Studio

# Useful Websites

{Make a list of websites that you found helpful in this project}
* [Android Developers](https://developer.android.com/)
* [StackOverflow](https://stackoverflow.com/)

# Future Work

{Make a list of things that you need to fix, improve, and add in the future.}
* Upgrade system
* Better UI
* Making a reset button