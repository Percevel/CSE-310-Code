package com.example.cookieclicker;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    ImageButton button;
    TextView text;
    int clicks = 0;
    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        try {
            //retrieving info for clicks
            SharedPreferences settings = getApplicationContext().getSharedPreferences("clicks", 0);
            clicks = settings.getInt("numberOfClicks", Context.MODE_PRIVATE);
        }
        finally {
            //setting up and making refs to buttons and text
            button = (ImageButton) findViewById(R.id.coookie);
            button.setOnClickListener(imgButtonHandler);
            text = (TextView)findViewById(R.id.textView2);
            text.setText(String.valueOf(clicks));
        }
    }

    public void changeImg(){
        //changes the image back to a cookie on a timer
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                button.setImageResource(R.drawable.coookie);
            }
        }, 200); //setting the timer
    }

    View.OnClickListener imgButtonHandler = new View.OnClickListener() {
        //making the constraints for what happens when the imagebutton is clicked
        public void onClick(View v) {
            button.setImageResource(R.drawable.coookie_bite);
            clicks++;
            text.setText(String.valueOf(clicks));
            //saves data
            saveData();
            //changes image back to cookie after a certain time
            changeImg();
        }
    };

    public void saveData(){
        //saves data to be called for later
        SharedPreferences settings = getApplicationContext().getSharedPreferences("clicks", 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putInt("numberOfClicks", clicks);
        editor.apply();
    }
}